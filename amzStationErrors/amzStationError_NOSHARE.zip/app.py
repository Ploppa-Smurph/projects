import os
from dotenv import load_dotenv
from flask import Flask, render_template

# Load environment variables from the .env file
load_dotenv()

from blueprints.reports.routes import reports_bp
from blueprints.drive.routes import drive_bp

# Create the Flask application instance
app = Flask(__name__)

# Register blueprints
app.register_blueprint(reports_bp, url_prefix='/reports')  # Register the reports blueprint with a URL prefix
app.register_blueprint(drive_bp, url_prefix='/drive')

# Home route 
@app.route('/')
def home():
    return render_template('home.html')

# About route
@app.route('/about')
def about():
    return render_template('about.html')

# Contact route.
@app.route('/contact')
def contact():
    return render_template('contact.html')

# Error handling
if __name__ == '__main__':
    app.run(debug=True)