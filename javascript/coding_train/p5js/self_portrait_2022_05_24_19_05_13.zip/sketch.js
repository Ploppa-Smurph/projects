function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(125, 75, 225);
  
  rect(100,75,25,75);
  rect(125,315,180,10);
  line(80,75,120,50)
  line(320, 15, 157, 17)

  ellipse(275, 88, 60, 120)
  triangle(200, 100, 300, 200, 140, 200)
}

 