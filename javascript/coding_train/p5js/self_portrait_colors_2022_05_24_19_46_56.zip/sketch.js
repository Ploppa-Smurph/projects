function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(105, 150, 225)
  
  strokeWeight(5)
    
  fill(01, 240, 210)
  stroke(240,0,105)  
  rect(100,75,25,75)  
  
  fill(101, 80, 110)
  stroke(40,150,205)
  rect(125,315,180,10)
  
  
  stroke(140, 90,05)
  line(80,75,120,50)
  
  line(320, 15, 157, 17)
  
  fill(125, 140, 110)
  stroke(90,40,205)
  ellipse(275, 88, 60, 120)
  
  fill(248, 140, 10)
  stroke(40,200,05)
  triangle(200, 100, 300, 200, 140, 200)
}
 