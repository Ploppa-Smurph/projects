import java.util.Random;
import java.util.Scanner;

// Enum for Pizza Sizes
enum PizzaSize {
    SMALL, MEDIUM, LARGE
}
public class PizzaPartyPlanner {

    // Function to calculate total cost
    public static double calculateTotalCost(int numPizzas) {
        double costPerPizza = 6.0;
        double taxRate = 0.10;
        double totalCostBeforeTax = numPizzas * costPerPizza;
        return totalCostBeforeTax * (1 + taxRate); // Adding tax
    }

public static void main(String[] args) {
    // Pre-set pizza sizes (can be changed)
    PizzaSize selectedSize = PizzaSize.SMALL;

    // Scanner to take user input
    Scanner scanner = new Scanner(System.in);

    // Ask the user how many pizzas they want to order
    System.out.print("How many pizzas would you like to order? ");
    int numPizzasOrdered = scanner.nextInt();

    // Randomly determine how many pizzas are actually made
    Random random = new Random();
    int numPizzasMade = random.nextInt(numPizzasOrdered) + 1;

    // Calculate total cost
    double totalCost = calculateTotalCost(numPizzasMade);

    // Output the results
    System.out.println(numPizzasMade + " " + selectedSize.name() + " pizzas were actually made.");
    System.out.printf("The total cost is $%.2f (including tax).\n", totalCost);

    // Close the scanner
    scanner.close();
   }
}