import java.util.Stack;

public class Main {
    public static boolean isBalanced(String str) {
        Stack<Character> stack = new Stack<>();

        for (char ch : str.toCharArray()) { //loop through all the characters
            if (ch == '(' || ch == '{' || ch == '[') { //push opening characters
                stack.push(ch);
            } else if (ch == ')' || ch == '}' || ch == ']') { //if a closing character...
                if (stack.isEmpty() || !isMatchingPair(stack.pop(), ch)) { //pop the value from the stack and compare
                    return false;
                }
            }
        }
        return stack.isEmpty();
    }

    //This helper function just simplifies the matching pair check in isBalanced(), returning true or false if they should match
    private static boolean isMatchingPair(char opening, char closing) {
        return (opening == '(' && closing == ')') ||
                (opening == '{' && closing == '}') ||
                (opening == '[' && closing == ']');
    }

    public static void main(String[] args) {
        //here are some tests...
        String[] testCases = {
                "{{[]()}}", //should be true
                "({}})", //should be false
                "([]{})", //should be true
                "([)]", //should be false
                "(()" //should be false
        };

        for (String testCase : testCases) {
            boolean isBalanced = isBalanced(testCase);
            System.out.println(testCase + " is balanced: " + isBalanced);
        }
    }
}