package palindromDetector;

public class Data {
    public static String[] getTestStrings() {
        return new String[]{"Racecar", "Tacocat", "A man a plan a canal Panama", "This is not a palindrome"};
    }
}