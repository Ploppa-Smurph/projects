package portfolio_comickeeper;

// created enum for grade which I will utilize in a 'switch' later in the program

public enum ComicGrade {
    FAIR,
    VG,
    VF,
    MINT,
}


