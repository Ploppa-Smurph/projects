package portfolio_comickeeper;

/*  I ended up utilizing output to .txt file,
-- but may incorporate creating a list first and then amending the list into the saved file when closing the app


public class ComicList {

}


*/