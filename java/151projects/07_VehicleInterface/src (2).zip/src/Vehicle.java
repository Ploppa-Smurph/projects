public interface Vehicle {
    void drive();
    void drive(int distance);
    int getMileage();
}
