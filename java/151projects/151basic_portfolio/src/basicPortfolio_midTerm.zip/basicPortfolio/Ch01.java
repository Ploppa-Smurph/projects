package basicPortfolio;

// Portfolio Ch1 - Write useful comments
// Every Java program has a main() that runs the application -- this program's main is in the 'BasicPortfolio' class
public class Ch01 {

    public void ch01() {
        // Portfolio Ch1 - Print to console
        System.out.println();
        System.out.println("This is the First Challenge of the Portfolio, Build a Working app that prints data to the console.");
    }
}
