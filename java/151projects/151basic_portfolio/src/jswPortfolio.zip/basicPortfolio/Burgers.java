package basicPortfolio;

public enum Burgers {
    CLASSIC,
    CHEESEBURGER,
    BBQ,
    BREAKFAST,
    VEGGIE,
}
