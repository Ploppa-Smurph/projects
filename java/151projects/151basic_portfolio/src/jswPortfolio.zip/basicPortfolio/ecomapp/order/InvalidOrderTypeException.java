package basicPortfolio.ecomapp.order;

public class InvalidOrderTypeException extends Exception {
  public InvalidOrderTypeException(String message) {
    super(message);
  }
}
