package basicPortfolio.ecomapp.order;

public class InvalidItemSelectionException extends Exception {
    public InvalidItemSelectionException(String message) {
        super(message);
    }
}
