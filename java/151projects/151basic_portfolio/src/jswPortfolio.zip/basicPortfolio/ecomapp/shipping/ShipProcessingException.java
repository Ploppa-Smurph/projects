package basicPortfolio.ecomapp.shipping;

public class ShipProcessingException extends Exception {
  public ShipProcessingException(String message) {
    super(message);
  }
}
