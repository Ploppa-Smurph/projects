package crybaby;

public class DumbGameException extends RuntimeException {
  public DumbGameException(String message) {
    super(message);
  }
}
