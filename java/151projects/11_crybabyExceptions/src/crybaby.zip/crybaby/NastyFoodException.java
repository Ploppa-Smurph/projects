package crybaby;

public class NastyFoodException extends RuntimeException {
    public NastyFoodException(String message) {
        super(message);
    }
}
