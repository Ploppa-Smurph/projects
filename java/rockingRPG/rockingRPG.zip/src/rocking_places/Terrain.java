package rocking_places;

public enum Terrain {
    GRASS, MOUNTAIN, WATER, DESERT, FOREST, TREASURE, ITEM, NPC, VILLAIN
}
