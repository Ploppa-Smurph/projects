package rocking_villains;

public enum VillainClass {
    ASSASSIN,
    BRUISER,
    WARLOCK,
    NECROMANCER,
    TECHNOMANCER,
    ROGUE,
    MARAUDER,
    HACKER,
    CYBORG,
    MUTANT
}
