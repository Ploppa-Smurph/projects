package rocking_exceptions;

public class InCombatException extends Exception {
    public InCombatException(String message) {
        super(message);
    }
}

