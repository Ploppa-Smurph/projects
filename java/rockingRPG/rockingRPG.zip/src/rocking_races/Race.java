package rocking_races;

// Define the Race enum
public enum Race {
        HUMONID,
        SYNTHZ,
        VEGLING,
        LIZARFOK,
        CRYOBORG
    }

