package rocking_classes;

// Define the Class enum
public enum HeroClass {
        MOUTH,
        SIX_STRING_SAMURAI,
        BASSZERKER,
        KEYCUSSION,
        BANGADON,
    }