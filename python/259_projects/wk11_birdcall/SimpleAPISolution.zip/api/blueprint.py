from flask import Blueprint, jsonify, current_app
from flask_httpauth import HTTPBasicAuth, HTTPTokenAuth
from itsdangerous import TimedJSONWebSignatureSerializer as Serializer
from models import birds

#create blueprint object
apiv1 = Blueprint('apiv1', __name__)

#create authentication management objects
token_auth = HTTPTokenAuth(scheme='Bearer')
login_auth = HTTPBasicAuth()

#configure errors for both handlers
@login_auth.error_handler
@token_auth.error_handler
def auth_error():
    return {
        'error': 'forbidden',
        'message': 'unauthorized credentials'
    }

#configure basic authentication verification
@login_auth.verify_password
def verify_password(username, password):
    if username == 'carl' and password == 'pass':
        return username
    else:
        return None

#configure token verification
@token_auth.verify_token
def verify_token(token):
    s = Serializer(current_app.config['SECRET_KEY'])
    try:
        data = s.loads(token)
    except:
        return None
    return data['username']

#set up token request route
@apiv1.route('/token')
@login_auth.login_required
def get_token():
    s = Serializer(current_app.config['SECRET_KEY'], expires_in=3600)
    token = s.dumps({'username': login_auth.current_user()}).decode('utf-8')
    return {
        "token": token,
        "expiration": 3600
    }

#set up other routes
@apiv1.route('/birds')
@token_auth.login_required
def all_birds():
    json_bird_list = []
    print(token_auth.current_user())
    for bird in birds:
        json_bird_list.append(bird.to_json())
    return {
        'user': token_auth.current_user(),
        'results': json_bird_list
    }

@apiv1.route('/birds/<id>')
@token_auth.login_required
def bird(id):
    id = int(id)
    bird = birds[id]
    return {
        'user': token_auth.current_user(),
        'results': bird.to_json()
        }