from flask import Flask, Blueprint, request
from api.blueprint import apiv1

#initialize flask
app = Flask(__name__)

#configure flask
app.config['SECRET_KEY'] = "asdefasdfasdf"
#initialize and configure plugins

#attach blueprints
app.register_blueprint(apiv1, url_prefix="/api/v1/")

@app.route('/')
def index():
    return "Hello!"

@app.errorhandler(404)
def page_not_found(e):
    if request.path.startswith('/api/'):
        return {
            'error': 'access error'
        }
    return e

if __name__ == '__main__':
    app.run(debug=True)