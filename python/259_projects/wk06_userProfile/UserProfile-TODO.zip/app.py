import os
from typing import Optional
from flask import Flask, flash, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import String, Text
from flask_login import LoginManager, UserMixin, current_user, login_user, login_required, logout_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, EqualTo, ValidationError

#configure
app = Flask(__name__)

basedir = os.path.abspath(os.path.dirname(__file__))

app.config["SECRET_KEY"] = "I really shouldn't put my secret key directly in my code"
app.config["SQLALCHEMY_DATABASE_URI"] = 'sqlite:///' + os.path.join(basedir, 'db.sqlite')

db = SQLAlchemy(app)
login = LoginManager(app)
#TODO - set the login view on the login object

#models

class User(UserMixin, db.Model):
    #TODO -set an int id that's a primary key
    #TODO - set a string name that's unique
    #TODO - set a profile Text that's optional
    #TODO -set a hashed password stored in a string

    #TODO - implement methods to set and check the password using hashes

    
#login user loader
    
#TODO - configure the login user_loader


#forms

class LoginForm(FlaskForm):
    name = StringField('name', validators=[DataRequired()])
    password = PasswordField("password", validators=[DataRequired()])
    submit = SubmitField("Sign In")

class RegistrationForm(FlaskForm):
    name = StringField('name', validators=[DataRequired()])
    password = PasswordField("password", validators=[DataRequired()])
    password2 = PasswordField("re-enter password", validators=[DataRequired(), EqualTo('password')])
    submit = SubmitField("Register")

    def validate_name(self, name):
        user = db.session.scalar(db.select(User).where(User.name == name.data))
        if user is not None:
            raise ValidationError("Please use a different name")
        
class ProfileUpdateForm(FlaskForm):
    profile = StringField('profile')
    submit = SubmitField("Update Profile")

#routes

@app.route("/")
def index():
    users = db.session.scalars(db.select(User))
    return render_template('index.html', users=users)

@app.route('/logout')
def logout():
    #TODO - logout the user
    return redirect(url_for('index'))

@app.route("/login", methods=["GET", "POST"])
def login():
    loginForm = LoginForm()
    if loginForm.validate_on_submit():
        #TODO - get the user based on their name
        #TODO - if the user doesn't exist or has an incorrect password:
            #TODO - flash an "invalid username or password" message
            #TODO - redirect back to login
        #otherwise...
        #TODO - login the user
        return redirect(url_for("profile", name=user.name))
    return render_template('login.html', form=loginForm)

@app.route("/register", methods=["GET", "POST"])
def register():
    #TODO - if the current user is already logged in, just redirect to index

    #otherwise create a registration form
    form = RegistrationForm()
    #TODO - if the form is valid
        #TODO - create the user
        #TODO - set the password
        #TODO - add the user to the database
        
        #TODO - log that user in
        #TODO - redirect to their profile page
    return render_template("register.html", form=form)

@app.route('/profile/<name>', methods=['GET', 'POST'])
#TODO - require login to view this route
def profile(name):
    #TODO - If the current user viewing their own page, display a ProfileUpdateForm
    #TODO - If that form validates, flash "Profile Updated" and update the profile for the user

    user = db.first_or_404(db.select(User).where(User.name==name))
    return render_template('profile.html', user=user)



#start
if __name__ == "__main__":
    app.run(debug=True)